// Random1.h

#ifndef RANDOM1_H
#define RANDOM1_H

//declarations of functions
//(prototypes)
double GetOneGaussianByBoxMuller();

#endif

